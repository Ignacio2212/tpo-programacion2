# Parte 2 - Despacho de Emergencias

## Integrante responsable
[Nombre Apellido]

## Funcionalidad
Despacho de emergencias en la ciudad. Ante múltiples accidentes, el
sistema asigna asistencia priorizando la gravedad del evento sobre el
orden cronológico del reporte. Permite:
- Registrar una nueva emergencia (con código, descripción, gravedad y ubicación).
- Actualizar el estado de una emergencia (pendiente / en_atencion / resuelta).
- Atender la emergencia de mayor gravedad pendiente.
- Listar las emergencias pendientes ordenadas por prioridad.
- Listar todas las emergencias registradas.

## Estructura de datos utilizada
**Cola de Prioridad (Heap, implementada con `PriorityQueue`)**: cada
emergencia se encola con su nivel de gravedad como prioridad (1 = más
grave). En caso de igual gravedad, se respeta el orden de llegada
(FIFO) mediante un contador de secuencia.

## Archivos
```
src/main/java/emergencias/
├── Emergencia.java               -> Entidad que representa una emergencia
├── ColaPrioridadEmergencias.java -> Estructura de datos (cola de prioridad)
└── GestorEmergencias.java        -> Lógica de la funcionalidad (interfaz para el Main)
```

## Paquete
`emergencias`
